import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { 
  Transaction, 
  CategoryItem, 
  SupabasePengurusRow, 
  DataWargaItem, 
  SekretariatItem, 
  InventarisItem, 
  PeminjamanItem 
} from '../types';
import { EmergencyAlertItem, fetchAllPengurusFromSupabase } from './supabase';
import { isWargaJabatan, sortPengurusByJabatan } from '../data/initialData';

export interface ExportOptions {
  filename?: string;
  scopeTitle?: string;
  includeSummary?: boolean;
  sekretariat?: {
    rt?: string;
    rw?: string;
    kelurahan?: string;
    kecamatan?: string;
    alamat?: string;
    kota_kabupaten?: string;
    provinsi?: string;
    kode_pos?: string;
  };
}

export interface AllTablesExportData {
  kas_rt: Transaction[];
  kategori?: CategoryItem[];
  data_warga?: DataWargaItem[];
  pengguna?: SupabasePengurusRow[];
  inventaris_rt?: InventarisItem[];
  peminjaman_aset_rt?: PeminjamanItem[];
  darurat_rt?: EmergencyAlertItem[];
  sekretariat?: SekretariatItem[];
}

/**
 * Ekspor data transaksi kas_rt ke format Microsoft Excel (.xlsx) asli
 */
export function exportToExcel(
  transactions: Transaction[],
  options: ExportOptions = {}
): void {
  const {
    scopeTitle = 'Semua Transaksi',
    includeSummary = true,
    sekretariat,
  } = options;

  const rtStr = sekretariat?.rt || '';
  const rwStr = sekretariat?.rw || '';
  const kelStr = (sekretariat?.kelurahan || '').toUpperCase();
  const kecStr = (sekretariat?.kecamatan || '').toUpperCase();
  const alamatStr = sekretariat?.alamat || (sekretariat?.rt && sekretariat?.rw ? `RT.${sekretariat.rt} RW.${sekretariat.rw}, Kel. ${sekretariat?.kelurahan || ''}` : '');

  const defaultFilename = `Kas_${rtStr ? `RT${rtStr}_` : ''}${rwStr ? `RW${rwStr}_` : ''}${new Date().toISOString().split('T')[0]}.xlsx`;
  const filename = options.filename || defaultFilename;

  let totalMasuk = 0;
  let totalKeluar = 0;

  transactions.forEach((t) => {
    const amt = Number(t.amount) || 0;
    if (t.type === 'Masuk') totalMasuk += amt;
    else if (t.type === 'Keluar') totalKeluar += amt;
  });

  const saldoBersih = totalMasuk - totalKeluar;

  const headerWilayah = [
    rtStr ? `RUKUN TETANGGA ${rtStr}` : 'RUKUN TETANGGA',
    rwStr ? `RUKUN WARGA ${rwStr}` : 'RUKUN WARGA'
  ].join(' ').toUpperCase();

  const sheetAoa: (string | number)[][] = [
    [`PENGURUS ${headerWilayah}`],
    [kelStr ? `KELURAHAN ${kelStr}${kecStr ? `, KECAMATAN ${kecStr}` : ''}` : 'BUKU KAS RT'],
    [`Alamat: ${alamatStr || '-'}`],
    [],
    ['LAPORAN REKAPITULASI MUTASI KAS WARGA'],
    [`Periode: ${scopeTitle} | Tanggal Dokumen: ${new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}`],
    [],
    ['No', 'Tanggal', 'Jenis', 'Kategori', 'Jumlah (Rp)', 'Keterangan', 'Status Sinkron', 'ID Transaksi', 'ID Warga'],
  ];

  transactions.forEach((t, idx) => {
    sheetAoa.push([
      idx + 1,
      t.date,
      t.type,
      t.category,
      Number(t.amount) || 0,
      t.description || '-',
      t.status || 'Synced',
      t.id,
      t.wargaId || '',
    ]);
  });

  if (includeSummary) {
    sheetAoa.push(
      [],
      ['', '', '', 'TOTAL KAS MASUK', totalMasuk, '', '', '', ''],
      ['', '', '', 'TOTAL KAS KELUAR', totalKeluar, '', '', '', ''],
      ['', '', '', 'SALDO BERSIH KAS', saldoBersih, '', '', '', '']
    );
  }

  const ws = XLSX.utils.aoa_to_sheet(sheetAoa);
  ws['!cols'] = [
    { wch: 6 },
    { wch: 14 },
    { wch: 12 },
    { wch: 22 },
    { wch: 18 },
    { wch: 45 },
    { wch: 15 },
    { wch: 38 },
    { wch: 38 },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, `Kas RT.${rtStr} RW.${rwStr}`);

  const finalFilename = filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`;
  XLSX.writeFile(wb, finalFilename);
}

/**
 * Ekspor seluruh 8 tabel ke format Excel Master Workbook (.xlsx) dengan 8 Lembar Kerja Terpisah
 */
export function exportAllTablesToExcel(
  tablesData: AllTablesExportData,
  options: ExportOptions = {}
): void {
  const { sekretariat } = options;
  const rtStr = sekretariat?.rt || '';
  const rwStr = sekretariat?.rw || '';
  const defaultFilename = `Master_8_Tabel_${rtStr ? `RT${rtStr}_` : ''}${rwStr ? `RW${rwStr}_` : ''}${new Date().toISOString().split('T')[0]}.xlsx`;
  const filename = options.filename || defaultFilename;

  const wb = XLSX.utils.book_new();

  // 1. Sheet Buku Kas RT (kas_rt)
  const kas = tablesData.kas_rt || [];
  const kasAoa: (string | number)[][] = [
    ['No', 'Tanggal', 'Jenis', 'Kategori', 'Jumlah (Rp)', 'Keterangan', 'ID Transaksi', 'ID Warga'],
  ];
  kas.forEach((t, idx) => {
    kasAoa.push([
      idx + 1,
      t.date,
      t.type,
      t.category,
      Number(t.amount) || 0,
      t.description || '-',
      t.id,
      t.wargaId || '',
    ]);
  });
  const wsKas = XLSX.utils.aoa_to_sheet(kasAoa);
  wsKas['!cols'] = [{ wch: 6 }, { wch: 14 }, { wch: 12 }, { wch: 24 }, { wch: 18 }, { wch: 40 }, { wch: 38 }, { wch: 38 }];
  XLSX.utils.book_append_sheet(wb, wsKas, 'Buku Kas RT');

  // 2. Sheet Master Kategori (kategori)
  const kat = tablesData.kategori || [];
  const katAoa: (string | number)[][] = [
    ['No', 'Nama Kategori', 'Jenis', 'Deskripsi / Peruntukan', 'Wajib / Sukarela', 'Nominal Acuan (Rp)', 'ID Kategori'],
  ];
  kat.forEach((k, idx) => {
    katAoa.push([
      idx + 1,
      k.name,
      k.type,
      k.description || '-',
      k.wajib ? 'Wajib' : 'Sukarela',
      k.nominal || 0,
      k.id,
    ]);
  });
  const wsKat = XLSX.utils.aoa_to_sheet(katAoa);
  wsKat['!cols'] = [{ wch: 6 }, { wch: 25 }, { wch: 14 }, { wch: 40 }, { wch: 18 }, { wch: 20 }, { wch: 38 }];
  XLSX.utils.book_append_sheet(wb, wsKat, 'Pos Kategori Kas');

  // 3. Sheet Data Warga (data_warga)
  const warga = tablesData.data_warga || [];
  const wargaAoa: (string | number)[][] = [
    ['No', 'No KK', 'NIK', 'Nama Lengkap', 'Jenis Kelamin', 'Tempat Lahir', 'Tanggal Lahir', 'Agama', 'Pendidikan', 'Pekerjaan', 'Status Perkawinan', 'Alamat Domisili', 'No HP', 'Status Warga', 'Catatan', 'ID Warga'],
  ];
  warga.forEach((w, idx) => {
    wargaAoa.push([
      idx + 1,
      w.no_kk,
      w.nik,
      w.nama_lengkap,
      w.jenis_kelamin || 'Laki-laki',
      w.tempat_lahir || '-',
      w.tanggal_lahir || '-',
      w.agama || 'Islam',
      w.pendidikan || '-',
      w.pekerjaan || '-',
      w.status_perkawinan || 'Belum Kawin',
      w.alamat_domisili,
      w.no_hp || '-',
      w.status_warga || 'Warga Tetap',
      w.catatan || '-',
      w.id || '',
    ]);
  });
  const wsWarga = XLSX.utils.aoa_to_sheet(wargaAoa);
  wsWarga['!cols'] = [{ wch: 6 }, { wch: 18 }, { wch: 18 }, { wch: 25 }, { wch: 15 }, { wch: 18 }, { wch: 14 }, { wch: 12 }, { wch: 16 }, { wch: 18 }, { wch: 18 }, { wch: 35 }, { wch: 16 }, { wch: 18 }, { wch: 25 }, { wch: 38 }];
  XLSX.utils.book_append_sheet(wb, wsWarga, 'Data Kependudukan');

  // 4. Sheet Pengguna / Pengurus (pengguna)
  const peng = tablesData.pengguna || [];
  const pengAoa: (string | number)[][] = [
    ['No', 'Nama Pengurus / Pengguna', 'Email', 'Jabatan', 'Level Akses', 'No HP', 'No KK', 'NIK', 'Alamat', 'Foto Profil (Base64)', 'ID Pengguna'],
  ];
  peng.forEach((p, idx) => {
    pengAoa.push([
      idx + 1,
      p.nama,
      p.email,
      p.jabatan,
      p.level_akses || 'User',
      p.no_hp || '-',
      p.no_kk || '-',
      p.nik || '-',
      p.alamat_domisili || '-',
      p.foto_url || (p as any).fotoUrl || '',
      p.id,
    ]);
  });
  const wsPeng = XLSX.utils.aoa_to_sheet(pengAoa);
  wsPeng['!cols'] = [{ wch: 6 }, { wch: 25 }, { wch: 28 }, { wch: 20 }, { wch: 14 }, { wch: 16 }, { wch: 18 }, { wch: 18 }, { wch: 30 }, { wch: 45 }, { wch: 38 }];
  XLSX.utils.book_append_sheet(wb, wsPeng, 'Data Pengguna Pengurus');

  // 5. Sheet Inventaris & Aset RT (inventaris_rt)
  const inv = tablesData.inventaris_rt || [];
  const invAoa: (string | number)[][] = [
    ['No', 'Nama Barang / Aset', 'Jumlah Total', 'Jumlah Baik', 'Jumlah Rusak', 'Kondisi', 'Lokasi Penyimpanan', 'Catatan', 'ID Barang'],
  ];
  inv.forEach((i, idx) => {
    invAoa.push([
      idx + 1,
      i.nama_barang,
      Number(i.jumlah_total) || 1,
      Number(i.jumlah_baik) || 1,
      Number(i.jumlah_rusak) || 0,
      i.kondisi || 'Baik',
      i.lokasi_penyimpanan || '-',
      i.catatan || '-',
      i.id,
    ]);
  });
  const wsInv = XLSX.utils.aoa_to_sheet(invAoa);
  wsInv['!cols'] = [{ wch: 6 }, { wch: 26 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 15 }, { wch: 25 }, { wch: 30 }, { wch: 38 }];
  XLSX.utils.book_append_sheet(wb, wsInv, 'Inventaris Aset RT');

  // 6. Sheet Log Peminjaman Aset (peminjaman_aset_rt)
  const pinjam = tablesData.peminjaman_aset_rt || [];
  const pinjamAoa: (string | number)[][] = [
    ['No', 'ID Barang', 'ID Warga', 'Tanggal Pinjam', 'Tanggal Kembali', 'Jumlah Pinjam', 'Keperluan', 'Status', 'Catatan', 'ID Peminjaman'],
  ];
  pinjam.forEach((pj, idx) => {
    pinjamAoa.push([
      idx + 1,
      pj.id_barang,
      pj.id_warga,
      pj.tanggal_pinjam,
      pj.tanggal_kembali || '-',
      Number(pj.jumlah_pinjam) || 1,
      pj.keperluan || '-',
      pj.status,
      pj.catatan || '-',
      pj.id,
    ]);
  });
  const wsPinjam = XLSX.utils.aoa_to_sheet(pinjamAoa);
  wsPinjam['!cols'] = [{ wch: 6 }, { wch: 38 }, { wch: 38 }, { wch: 15 }, { wch: 15 }, { wch: 15 }, { wch: 25 }, { wch: 14 }, { wch: 25 }, { wch: 38 }];
  XLSX.utils.book_append_sheet(wb, wsPinjam, 'Peminjaman Aset');

  // 7. Sheet Log Darurat SOS (darurat_rt)
  const darurat = tablesData.darurat_rt || [];
  const daruratAoa: (string | number)[][] = [
    ['No', 'Nama Warga', 'Alamat', 'No HP', 'Tipe Darurat', 'Status', 'Keterangan', 'Waktu Dibuat', 'ID Log Darurat'],
  ];
  darurat.forEach((d, idx) => {
    daruratAoa.push([
      idx + 1,
      d.nama_warga,
      d.alamat,
      d.no_hp || '-',
      d.tipe_darurat,
      d.status,
      d.keterangan || '-',
      d.created_at || '-',
      d.id,
    ]);
  });
  const wsDarurat = XLSX.utils.aoa_to_sheet(daruratAoa);
  wsDarurat['!cols'] = [{ wch: 6 }, { wch: 24 }, { wch: 30 }, { wch: 16 }, { wch: 20 }, { wch: 12 }, { wch: 30 }, { wch: 22 }, { wch: 38 }];
  XLSX.utils.book_append_sheet(wb, wsDarurat, 'Log Darurat SOS');

  // 8. Sheet Profil Sekretariat (sekretariat)
  const sek = tablesData.sekretariat || (sekretariat ? [sekretariat as SekretariatItem] : []);
  const sekAoa: (string | number)[][] = [
    ['RT', 'RW', 'Kelurahan', 'Kecamatan', 'Alamat Sekretariat', 'Kota/Kabupaten', 'Provinsi', 'Kode Pos', 'Telepon', 'Nama Ketua RT'],
  ];
  sek.forEach((s) => {
    sekAoa.push([
      s.rt || '',
      s.rw || '',
      s.kelurahan || '',
      s.kecamatan || '',
      s.alamat || '',
      s.kota_kabupaten || '',
      s.provinsi || '',
      s.kode_pos || '',
      s.telepon || '',
      s.nama_ketua_rt || '',
    ]);
  });
  const wsSek = XLSX.utils.aoa_to_sheet(sekAoa);
  wsSek['!cols'] = [{ wch: 8 }, { wch: 8 }, { wch: 20 }, { wch: 20 }, { wch: 35 }, { wch: 20 }, { wch: 20 }, { wch: 12 }, { wch: 16 }, { wch: 25 }];
  XLSX.utils.book_append_sheet(wb, wsSek, 'Profil Sekretariat');

  const finalFilename = filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`;
  XLSX.writeFile(wb, finalFilename);
}

/**
 * Ekspor data transaksi ke format CSV dengan UTF-8 BOM
 */
export function exportToCSV(
  transactions: Transaction[],
  options: ExportOptions = {}
): void {
  const {
    scopeTitle = 'Semua Transaksi',
    sekretariat,
  } = options;

  const rtStr = sekretariat?.rt || '';
  const rwStr = sekretariat?.rw || '';
  const kelStr = sekretariat?.kelurahan || '';
  const wilayahIdent = rtStr && rwStr ? `RT.${rtStr} RW.${rwStr}` : 'Kas RT';

  const defaultFilename = `Kas_${rtStr ? `RT${rtStr}_` : ''}${rwStr ? `RW${rwStr}_` : ''}${new Date().toISOString().split('T')[0]}.csv`;
  const filename = options.filename || defaultFilename;

  const headers = ['No', 'Tanggal', 'Jenis', 'Kategori', 'Jumlah (Rp)', 'Keterangan', 'Status Sinkron', 'ID Transaksi', 'ID Warga'];
  
  const rows = transactions.map((t, idx) => [
    idx + 1,
    t.date,
    t.type,
    `"${(t.category || '').replace(/"/g, '""')}"`,
    t.amount,
    `"${(t.description || '').replace(/"/g, '""')}"`,
    t.status || 'Synced',
    `"${t.id}"`,
    `"${t.wargaId || ''}"`,
  ]);

  const csvContent =
    '\uFEFF' +
    `# BUKU KAS ${wilayahIdent}${kelStr ? ` - Kelurahan ${kelStr}` : ''}\n` +
    `# Cakupan: ${scopeTitle} | Tanggal Ekspor: ${new Date().toLocaleDateString('id-ID')}\n` +
    [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename.endsWith('.csv') ? filename : `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Ekspor data transaksi ke format JSON (struktur backup)
 */
export function exportToJSON(
  transactions: Transaction[],
  options: ExportOptions = {}
): void {
  const {
    scopeTitle = 'Semua Transaksi',
    sekretariat,
  } = options;

  const rtStr = sekretariat?.rt || '';
  const rwStr = sekretariat?.rw || '';
  const kelStr = sekretariat?.kelurahan || '';
  const kecStr = sekretariat?.kecamatan || '';
  const wilayahIdent = rtStr && rwStr ? `RT.${rtStr} RW.${rwStr}` : 'Kas RT';

  const defaultFilename = `Kas_${rtStr ? `RT${rtStr}_` : ''}${rwStr ? `RW${rwStr}_` : ''}Backup_${new Date().toISOString().split('T')[0]}.json`;
  const filename = options.filename || defaultFilename;

  let totalMasuk = 0;
  let totalKeluar = 0;
  transactions.forEach((t) => {
    const amt = Number(t.amount) || 0;
    if (t.type === 'Masuk') totalMasuk += amt;
    else if (t.type === 'Keluar') totalKeluar += amt;
  });

  const payload = {
    aplikasi: `Kas ${wilayahIdent}`,
    wilayah: [
      rtStr ? `RT.${rtStr}` : '',
      rwStr ? `RW.${rwStr}` : '',
      kelStr ? `Kelurahan ${kelStr}` : '',
      kecStr ? `Kecamatan ${kecStr}` : '',
    ].filter(Boolean).join(', ') || 'Sistem Kas RT',
    cakupan: scopeTitle,
    tanggal_ekspor: new Date().toISOString(),
    total_transaksi: transactions.length,
    ringkasan: {
      total_kas_masuk: totalMasuk,
      total_kas_keluar: totalKeluar,
      saldo_bersih: totalMasuk - totalKeluar,
    },
    transaksi: transactions,
  };

  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(payload, null, 2));
  const link = document.createElement('a');
  link.setAttribute('href', dataStr);
  link.setAttribute('download', filename.endsWith('.json') ? filename : `${filename}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Menghasilkan teks query SQL MySQL (DDL CREATE TABLE + DML INSERT VALUES) untuk seluruh 8 tabel resmi
 */
export function generateMySQLDump(
  transactions: Transaction[],
  scopeTitle: string = 'Semua Transaksi',
  sekretariat?: ExportOptions['sekretariat'],
  extraTables?: {
    kategori?: CategoryItem[];
    data_warga?: DataWargaItem[];
    pengguna?: SupabasePengurusRow[];
    inventaris_rt?: InventarisItem[];
    peminjaman_aset_rt?: PeminjamanItem[];
    darurat_rt?: EmergencyAlertItem[];
  }
): string {
  const exportDate = new Date().toISOString().replace('T', ' ').substring(0, 19);

  const rtStr = sekretariat?.rt || '';
  const rwStr = sekretariat?.rw || '';
  const kelStr = sekretariat?.kelurahan || '';
  const kecStr = sekretariat?.kecamatan || '';
  const wilayahIdent = rtStr && rwStr ? `RT.${rtStr} RW.${rwStr}` : 'Kas RT';

  let sql = `-- =============================================================================\n`;
  sql += `-- DUMP STRUKTUR & DATA DATABASE MYSQL LENGKAP: 8 TABEL RESMI\n`;
  sql += `-- Aplikasi: Sistem Buku Kas & Manajemen ${wilayahIdent}\n`;
  sql += `-- Wilayah: ${[rtStr && `RT.${rtStr}`, rwStr && `RW.${rwStr}`, kelStr && `Kelurahan ${kelStr}`, kecStr && `Kec. ${kecStr}`].filter(Boolean).join(', ') || 'Sistem Kas RT'}\n`;
  sql += `-- Cakupan: ${scopeTitle} (${transactions.length} baris data kas)\n`;
  sql += `-- Tanggal Pembuatan: ${exportDate} WIB\n`;
  sql += `-- Target: MySQL 5.7+, MySQL 8.0+, MariaDB 10.3+\n`;
  sql += `-- Karakter Encoding: UTF-8 (utf8mb4)\n`;
  sql += `-- =============================================================================\n\n`;

  sql += `SET NAMES utf8mb4;\n`;
  sql += `SET FOREIGN_KEY_CHECKS = 0;\n`;
  sql += `SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n\n`;

  // 1. sekretariat
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `-- 1. TABEL: sekretariat\n`;
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `DROP TABLE IF EXISTS \`sekretariat\`;\n`;
  sql += `CREATE TABLE \`sekretariat\` (\n`;
  sql += `  \`id\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`rt\` VARCHAR(10) NOT NULL,\n`;
  sql += `  \`rw\` VARCHAR(10) NOT NULL,\n`;
  sql += `  \`kelurahan\` VARCHAR(100) NOT NULL,\n`;
  sql += `  \`kecamatan\` VARCHAR(100) NOT NULL,\n`;
  sql += `  \`alamat\` TEXT NOT NULL,\n`;
  sql += `  PRIMARY KEY (\`id\`)\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  if (sekretariat && (sekretariat.rt || sekretariat.rw)) {
    sql += `INSERT INTO \`sekretariat\` VALUES ('00000000-0000-0000-0000-000000000001', '${(sekretariat.rt || '').replace(/'/g, "\\'")}', '${(sekretariat.rw || '').replace(/'/g, "\\'")}', '${(sekretariat.kelurahan || '').replace(/'/g, "\\'")}', '${(sekretariat.kecamatan || '').replace(/'/g, "\\'")}', '${(sekretariat.alamat || '').replace(/'/g, "\\'")}');\n\n`;
  }

  // 2. kategori
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `-- 2. TABEL: kategori\n`;
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `DROP TABLE IF EXISTS \`kategori\`;\n`;
  sql += `CREATE TABLE \`kategori\` (\n`;
  sql += `  \`id\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`nama\` VARCHAR(100) NOT NULL,\n`;
  sql += `  \`jenis\` ENUM('Masuk', 'Keluar') NOT NULL,\n`;
  sql += `  \`deskripsi\` TEXT,\n`;
  sql += `  \`wajib\` TINYINT(1) NOT NULL DEFAULT '0',\n`;
  sql += `  \`nominal\` DECIMAL(15, 2) NOT NULL DEFAULT '0.00',\n`;
  sql += `  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n`;
  sql += `  PRIMARY KEY (\`id\`),\n`;
  sql += `  UNIQUE KEY \`uniq_nama_jenis\` (\`nama\`, \`jenis\`)\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  // 3. data_warga
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `-- 3. TABEL: data_warga\n`;
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `DROP TABLE IF EXISTS \`data_warga\`;\n`;
  sql += `CREATE TABLE \`data_warga\` (\n`;
  sql += `  \`id\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`no_kk\` VARCHAR(16) NOT NULL,\n`;
  sql += `  \`nik\` VARCHAR(16) NOT NULL,\n`;
  sql += `  \`nama_lengkap\` VARCHAR(150) NOT NULL,\n`;
  sql += `  \`jenis_kelamin\` ENUM('Laki-laki', 'Perempuan') DEFAULT 'Laki-laki',\n`;
  sql += `  \`tempat_lahir\` VARCHAR(100) DEFAULT NULL,\n`;
  sql += `  \`tanggal_lahir\` DATE DEFAULT NULL,\n`;
  sql += `  \`agama\` VARCHAR(30) DEFAULT 'Islam',\n`;
  sql += `  \`pendidikan\` VARCHAR(50) DEFAULT NULL,\n`;
  sql += `  \`pekerjaan\` VARCHAR(80) DEFAULT NULL,\n`;
  sql += `  \`status_perkawinan\` VARCHAR(30) DEFAULT 'Belum Kawin',\n`;
  sql += `  \`alamat_domisili\` TEXT NOT NULL,\n`;
  sql += `  \`no_hp\` VARCHAR(20) DEFAULT NULL,\n`;
  sql += `  \`status_warga\` VARCHAR(50) DEFAULT 'Warga Tetap',\n`;
  sql += `  \`catatan\` TEXT,\n`;
  sql += `  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n`;
  sql += `  PRIMARY KEY (\`id\`),\n`;
  sql += `  UNIQUE KEY \`uniq_nik\` (\`nik\`),\n`;
  sql += `  KEY \`idx_no_kk\` (\`no_kk\`)\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  // 4. pengguna
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `-- 4. TABEL: pengguna\n`;
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `DROP TABLE IF EXISTS \`pengguna\`;\n`;
  sql += `CREATE TABLE \`pengguna\` (\n`;
  sql += `  \`id\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`nama\` VARCHAR(150) NOT NULL,\n`;
  sql += `  \`email\` VARCHAR(100) NOT NULL,\n`;
  sql += `  \`password\` VARCHAR(255) NOT NULL,\n`;
  sql += `  \`jabatan\` VARCHAR(50) NOT NULL,\n`;
  sql += `  \`level_akses\` ENUM('Admin', 'User') NOT NULL DEFAULT 'User',\n`;
  sql += `  \`no_hp\` VARCHAR(20) DEFAULT NULL,\n`;
  sql += `  \`no_kk\` VARCHAR(16) DEFAULT NULL,\n`;
  sql += `  \`warga_id\` VARCHAR(36) DEFAULT NULL,\n`;
  sql += `  \`nik\` VARCHAR(16) DEFAULT NULL,\n`;
  sql += `  \`alamat_domisili\` TEXT,\n`;
  sql += `  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n`;
  sql += `  PRIMARY KEY (\`id\`),\n`;
  sql += `  UNIQUE KEY \`uniq_email\` (\`email\`)\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  // 5. kas_rt
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `-- 5. TABEL: kas_rt\n`;
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `DROP TABLE IF EXISTS \`kas_rt\`;\n`;
  sql += `CREATE TABLE \`kas_rt\` (\n`;
  sql += `  \`id\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`tanggal\` DATE NOT NULL,\n`;
  sql += `  \`jenis\` ENUM('Masuk', 'Keluar') NOT NULL,\n`;
  sql += `  \`kategori\` VARCHAR(100) NOT NULL,\n`;
  sql += `  \`jumlah\` DECIMAL(15, 2) NOT NULL DEFAULT '0.00',\n`;
  sql += `  \`keterangan\` TEXT NOT NULL,\n`;
  sql += `  \`warga_id\` VARCHAR(36) DEFAULT NULL,\n`;
  sql += `  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n`;
  sql += `  PRIMARY KEY (\`id\`),\n`;
  sql += `  KEY \`idx_tanggal\` (\`tanggal\`),\n`;
  sql += `  KEY \`idx_jenis\` (\`jenis\`)\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  if (transactions.length > 0) {
    sql += `INSERT INTO \`kas_rt\` (\`id\`, \`tanggal\`, \`jenis\`, \`kategori\`, \`jumlah\`, \`keterangan\`, \`warga_id\`, \`created_at\`) VALUES\n`;
    const values = transactions.map((t) => {
      const escapedId = (t.id || '').replace(/'/g, "\\'");
      const escapedDate = (t.date || new Date().toISOString().split('T')[0]).replace(/'/g, "\\'");
      const jenis = t.type === 'Keluar' ? 'Keluar' : 'Masuk';
      const escapedCat = (t.category || 'Lainnya').replace(/'/g, "\\'");
      const amt = Number(t.amount) || 0;
      const escapedDesc = (t.description || '').replace(/'/g, "\\'").replace(/\n/g, '\\n').replace(/\r/g, '');
      const escapedWargaId = t.wargaId ? `'${t.wargaId.replace(/'/g, "\\'")}'` : 'NULL';
      const createdAtStr = t.createdAt
        ? new Date(t.createdAt).toISOString().replace('T', ' ').substring(0, 19)
        : `${escapedDate} 07:00:00`;
      return `  ('${escapedId}', '${escapedDate}', '${jenis}', '${escapedCat}', ${amt.toFixed(2)}, '${escapedDesc}', ${escapedWargaId}, '${createdAtStr}')`;
    });
    sql += values.join(',\n') + ';\n\n';
  }

  // 6. darurat_rt
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `-- 6. TABEL: darurat_rt\n`;
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `DROP TABLE IF EXISTS \`darurat_rt\`;\n`;
  sql += `CREATE TABLE \`darurat_rt\` (\n`;
  sql += `  \`id\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`id_warga\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`nama_warga\` VARCHAR(150) NOT NULL,\n`;
  sql += `  \`alamat\` TEXT NOT NULL,\n`;
  sql += `  \`no_hp\` VARCHAR(20) DEFAULT NULL,\n`;
  sql += `  \`tipe_darurat\` VARCHAR(50) NOT NULL,\n`;
  sql += `  \`status\` ENUM('Aktif', 'Selesai') NOT NULL DEFAULT 'Aktif',\n`;
  sql += `  \`keterangan\` TEXT,\n`;
  sql += `  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n`;
  sql += `  PRIMARY KEY (\`id\`)\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  // 7. inventaris_rt
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `-- 7. TABEL: inventaris_rt\n`;
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `DROP TABLE IF EXISTS \`inventaris_rt\`;\n`;
  sql += `CREATE TABLE \`inventaris_rt\` (\n`;
  sql += `  \`id\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`nama_barang\` VARCHAR(150) NOT NULL,\n`;
  sql += `  \`jumlah_total\` INT NOT NULL DEFAULT '1',\n`;
  sql += `  \`jumlah_baik\` INT NOT NULL DEFAULT '1',\n`;
  sql += `  \`jumlah_rusak\` INT NOT NULL DEFAULT '0',\n`;
  sql += `  \`kondisi\` VARCHAR(50) DEFAULT 'Baik',\n`;
  sql += `  \`lokasi_penyimpanan\` VARCHAR(150) DEFAULT NULL,\n`;
  sql += `  \`catatan\` TEXT,\n`;
  sql += `  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n`;
  sql += `  PRIMARY KEY (\`id\`)\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  // 8. peminjaman_aset_rt
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `-- 8. TABEL: peminjaman_aset_rt\n`;
  sql += `-- -----------------------------------------------------------------------------\n`;
  sql += `DROP TABLE IF EXISTS \`peminjaman_aset_rt\`;\n`;
  sql += `CREATE TABLE \`peminjaman_aset_rt\` (\n`;
  sql += `  \`id\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`id_barang\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`id_warga\` VARCHAR(36) NOT NULL,\n`;
  sql += `  \`tanggal_pinjam\` DATE NOT NULL,\n`;
  sql += `  \`tanggal_kembali\` DATE DEFAULT NULL,\n`;
  sql += `  \`jumlah_pinjam\` INT NOT NULL DEFAULT '1',\n`;
  sql += `  \`keperluan\` TEXT,\n`;
  sql += `  \`status\` ENUM('Dipinjam', 'Kembali') NOT NULL DEFAULT 'Dipinjam',\n`;
  sql += `  \`catatan\` TEXT,\n`;
  sql += `  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n`;
  sql += `  PRIMARY KEY (\`id\`)\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  sql += `SET FOREIGN_KEY_CHECKS = 1;\n`;
  return sql;
}

/**
 * Ekspor data transaksi kas_rt ke format file SQL MySQL (.sql) siap import
 */
export function exportToMySQL(
  transactions: Transaction[],
  options: ExportOptions = {}
): void {
  const {
    scopeTitle = 'Semua Transaksi',
    sekretariat,
  } = options;

  const rtStr = sekretariat?.rt || '';
  const rwStr = sekretariat?.rw || '';

  const defaultFilename = `kas_rt_mysql_${rtStr ? `RT${rtStr}_` : ''}${rwStr ? `RW${rwStr}_` : ''}${new Date().toISOString().split('T')[0]}.sql`;
  const filename = options.filename || defaultFilename;

  const sqlContent = generateMySQLDump(transactions, scopeTitle, sekretariat);
  const blob = new Blob([sqlContent], { type: 'application/sql;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename.endsWith('.sql') ? filename : `${filename}.sql`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}


/**
 * Konversi logo RT (SVG) dari /rt_logo.svg menjadi Base64 PNG Data URL untuk disisipkan ke PDF
 */
export function getRtLogoBase64(): Promise<string | null> {
  if (typeof window === 'undefined') return Promise.resolve(null);
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth || 240;
        canvas.height = img.naturalHeight || 240;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          resolve(canvas.toDataURL('image/png'));
          return;
        }
      } catch (e) {
        console.warn('[getRtLogoBase64] Canvas error', e);
      }
      resolve(null);
    };
    img.onerror = () => resolve(null);
    img.src = '/rt_logo.svg';
  });
}

/**
 * Ekspor data warga ke format PDF Laporan Resmi Kependudukan
 */
export async function exportDataWargaPDF(
  wargaList: any[],
  options: {
    sekretariat?: {
      rt?: string;
      rw?: string;
      kelurahan?: string;
      kecamatan?: string;
      alamat?: string;
      kota_kabupaten?: string;
      provinsi?: string;
      nama_ketua_rt?: string;
    };
    pengguna?: SupabasePengurusRow[];
    filterLabel?: string;
    filename?: string;
  } = {}
): Promise<void> {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

  const rtStr = options.sekretariat?.rt || '002';
  const rwStr = options.sekretariat?.rw || '09';
  const kelStr = (options.sekretariat?.kelurahan || 'Pondok Rajeg').toUpperCase();
  const kecStr = (options.sekretariat?.kecamatan || 'Cibinong').toUpperCase();
  const alamatStr = options.sekretariat?.alamat || `RT.${rtStr} RW.${rwStr}, Kel. ${options.sekretariat?.kelurahan || 'Pondok Rajeg'}`;

  // Ambil data pengguna dari database/options jika belum ada
  let penggunaList: SupabasePengurusRow[] = options.pengguna || [];
  if (!penggunaList || penggunaList.length === 0) {
    try {
      penggunaList = await fetchAllPengurusFromSupabase();
    } catch {}
  }

  // Cari data Ketua RT dari tabel pengguna
  const ketuaUser = penggunaList.find((p) => 
    p.jabatan && p.jabatan.toLowerCase().includes('ketua')
  ) || penggunaList.find((p) => p.level_akses === 'Admin') || penggunaList[0];

  const ketuaNama = ketuaUser?.nama || options.sekretariat?.nama_ketua_rt || 'Bpk. Ketua RT';
  const ketuaJabatan = ketuaUser?.jabatan || `Ketua RT.${rtStr} RW.${rwStr}`;

  // Coba ambil logo RT
  let logoDataUrl: string | null = null;
  try {
    logoDataUrl = await getRtLogoBase64();
  } catch (e) {
    console.warn('[PDF Export] Logo load error', e);
  }

  const startX = logoDataUrl ? 33 : 14;

  if (logoDataUrl) {
    doc.addImage(logoDataUrl, 'PNG', 14, 11, 16, 16);
  }

  // Kop Surat
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text(`PENGURUS RUKUN TETANGGA ${rtStr} RUKUN WARGA ${rwStr}`, startX, 15);

  doc.setFontSize(10);
  doc.text(`KELURAHAN ${kelStr}${kecStr ? `, KECAMATAN ${kecStr}` : ''}`, startX, 21);

  doc.setFontSize(8.5);
  doc.setFont('Helvetica', 'normal');
  doc.text(`Alamat Sekretariat: ${alamatStr}`, startX, 26);

  // Garis Pembatas
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.8);
  doc.line(14, 29, 283, 29);
  doc.setLineWidth(0.2);
  doc.line(14, 30, 283, 30);

  // Judul Laporan
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(12);
  doc.text(`LAPORAN DATA KEPENDUDUKAN & WARGA RT.${rtStr} RW.${rwStr}`, 14, 37);

  doc.setFontSize(8.5);
  doc.setFont('Helvetica', 'normal');
  const filterLabel = options.filterLabel || 'Semua Data Warga';
  const tglCetak = new Date().toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  
  const totalTetap = wargaList.filter(w => !w.status_warga || w.status_warga === 'Warga Tetap').length;
  const totalKontrak = wargaList.length - totalTetap;

  // Hapus '/Jiwa' -> gunakan 'Total: xx KK'
  doc.text(`Kategori: ${filterLabel} | Total: ${wargaList.length} KK (${totalTetap} Tetap, ${totalKontrak} Kontrak/Kos) | Tanggal Cetak: ${tglCetak}`, 14, 42);

  // Tabel Data Warga
  const tableHeaders = [
    ['NO', 'NAMA LENGKAP', 'NIK / NO. KK', 'L/P', 'PEKERJAAN', 'ALAMAT DOMISILI', 'STATUS WARGA', 'NO. TELEPON / WA']
  ];

  const tableBody = wargaList.map((w, idx) => {
    const statusText = w.status_warga || 'Warga Tetap';
    const nikKk = `NIK: ${w.nik || '-'}\nKK: ${w.no_kk || '-'}`;
    const gender = w.jenis_kelamin === 'Perempuan' ? 'P' : 'L';
    return [
      idx + 1,
      w.nama_lengkap || '-',
      nikKk,
      gender,
      w.pekerjaan || '-',
      w.alamat_domisili || `RT.${rtStr} RW.${rwStr}`,
      statusText,
      w.no_hp || '-'
    ];
  });

  autoTable(doc, {
    startY: 46,
    head: tableHeaders,
    body: tableBody,
    theme: 'grid',
    headStyles: {
      fillColor: [15, 23, 42],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'center',
    },
    bodyStyles: {
      fontSize: 8,
      textColor: [30, 41, 59],
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 46, fontStyle: 'bold' },
      2: { cellWidth: 42 },
      3: { cellWidth: 10, halign: 'center' },
      4: { cellWidth: 35 },
      5: { cellWidth: 54 },
      6: { cellWidth: 32, halign: 'center' },
      7: { cellWidth: 35 },
    },
    margin: { left: 14, right: 14 },
  });

  // Tanda Tangan
  const finalY = (doc as any).lastAutoTable?.finalY || 150;
  const signY = finalY + 10 > 170 ? 170 : finalY + 10;
  const locationName = options.sekretariat?.kelurahan || options.sekretariat?.kota_kabupaten || 'Pondok Rajeg';

  if (signY < 185) {
    doc.setFontSize(8.5);
    doc.setFont('Helvetica', 'normal');
    doc.setTextColor(30, 41, 59);

    // Dynamic location string using kelurahan or city from sekretariat
    doc.text(`${locationName}, ${tglCetak}`, 220, signY);
    doc.text(`Mengetahui,`, 220, signY + 5);
    
    // Nama Ketua RT di atas garis (dari tabel pengguna field nama)
    doc.setFont('Helvetica', 'bold');
    doc.text(`${ketuaNama}`, 220, signY + 20);

    // Garis tanda tangan (digeser ke bawah 2mm agar berjarak elegan dan tidak menempel dengan nama)
    doc.setDrawColor(30, 41, 59);
    doc.setLineWidth(0.4);
    doc.line(220, signY + 23, 275, signY + 23);

    // Jabatan Ketua RT di bawah garis (dari tabel pengguna field jabatan)
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`${ketuaJabatan}`, 220, signY + 28.5);
  }

  // Footer Nomor Halaman
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setFont('Helvetica', 'italic');
    doc.setTextColor(100, 116, 139);
    doc.text(
      `Halaman ${i} dari ${pageCount} — Dokumen Resmi Data Warga RT.${rtStr} RW.${rwStr}`,
      14,
      202
    );
  }

  const defaultFilename = `Laporan_Data_Warga_RT${rtStr}_RW${rwStr}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(options.filename || defaultFilename);
}

/**
 * Ekspor data inventaris & aset RT ke format PDF Laporan Resmi
 */
export async function exportInventarisPDF(
  assets: InventarisItem[],
  options: {
    sekretariat?: {
      rt?: string;
      rw?: string;
      kelurahan?: string;
      kecamatan?: string;
      alamat?: string;
      kota_kabupaten?: string;
      provinsi?: string;
      nama_ketua_rt?: string;
    };
    pengguna?: SupabasePengurusRow[];
    filterLabel?: string;
    filename?: string;
    activeSubTab?: 'daftar-aset' | 'log-peminjaman';
    loans?: any[];
  } = {}
): Promise<void> {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

  const rtStr = options.sekretariat?.rt || '002';
  const rwStr = options.sekretariat?.rw || '09';
  const kelStr = (options.sekretariat?.kelurahan || 'Pondok Rajeg').toUpperCase();
  const kecStr = (options.sekretariat?.kecamatan || 'Cibinong').toUpperCase();
  const alamatStr = options.sekretariat?.alamat || `RT.${rtStr} RW.${rwStr}, Kel. ${options.sekretariat?.kelurahan || 'Pondok Rajeg'}`;

  // Ambil data pengguna dari database/options jika belum ada
  let penggunaList: SupabasePengurusRow[] = options.pengguna || [];
  if (!penggunaList || penggunaList.length === 0) {
    try {
      penggunaList = await fetchAllPengurusFromSupabase();
    } catch {}
  }

  // Cari data Ketua RT atau Seksi Sarana & Prasarana
  const saranaUser = penggunaList.find((p) =>
    p.jabatan && (p.jabatan.toLowerCase().includes('sarana') || p.jabatan.toLowerCase().includes('prasarana'))
  );
  const ketuaUser = penggunaList.find((p) => 
    p.jabatan && p.jabatan.toLowerCase().includes('ketua')
  ) || penggunaList.find((p) => p.level_akses === 'Admin') || penggunaList[0];

  const ketuaNama = ketuaUser?.nama || options.sekretariat?.nama_ketua_rt || 'Bpk. Ketua RT';
  const ketuaJabatan = ketuaUser?.jabatan || `Ketua RT.${rtStr} RW.${rwStr}`;
  const saranaNama = saranaUser?.nama || 'Seksi Sarana & Prasarana';

  // Logo RT
  let logoDataUrl: string | null = null;
  try {
    logoDataUrl = await getRtLogoBase64();
  } catch (e) {
    console.warn('[PDF Export] Logo load error', e);
  }

  const startX = logoDataUrl ? 33 : 14;

  if (logoDataUrl) {
    doc.addImage(logoDataUrl, 'PNG', 14, 11, 16, 16);
  }

  // Kop Surat
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text(`PENGURUS RUKUN TETANGGA ${rtStr} RUKUN WARGA ${rwStr}`, startX, 15);

  doc.setFontSize(10);
  doc.text(`KELURAHAN ${kelStr}${kecStr ? `, KECAMATAN ${kecStr}` : ''}`, startX, 21);

  doc.setFontSize(8.5);
  doc.setFont('Helvetica', 'normal');
  doc.text(`Alamat Sekretariat: ${alamatStr}`, startX, 26);

  // Garis Pembatas Kop Surat
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.8);
  doc.line(14, 29, 283, 29);
  doc.setLineWidth(0.2);
  doc.line(14, 30, 283, 30);

  const isLoanTab = options.activeSubTab === 'log-peminjaman';
  const tglCetak = new Date().toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const filterLabel = options.filterLabel || (isLoanTab ? 'Semua Catatan Peminjaman' : 'Semua Aset Inventaris');

  if (isLoanTab) {
    const loanList = options.loans || [];
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(12);
    doc.text(`LAPORAN LOG PEMINJAMAN ASET RT.${rtStr} RW.${rwStr}`, 14, 37);

    doc.setFontSize(8.5);
    doc.setFont('Helvetica', 'normal');
    const dipinjamCount = loanList.filter((l: any) => l.status === 'Dipinjam').length;
    const kembaliCount = loanList.filter((l: any) => l.status === 'Kembali').length;
    doc.text(
      `Cakupan: ${filterLabel} | Total: ${loanList.length} Catatan (${dipinjamCount} Sedang Dipinjam, ${kembaliCount} Selesai) | Tanggal Cetak: ${tglCetak}`,
      14,
      42
    );

    const headers = [
      ['NO', 'NAMA BARANG', 'WARGA PEMINJAM', 'NO HP / WA', 'TGL PINJAM', 'TGL KEMBALI', 'JUMLAH', 'KEPERLUAN / CATATAN', 'STATUS']
    ];

    const body = loanList.map((l: any, idx: number) => [
      idx + 1,
      l.barang_nama || 'Barang RT',
      l.warga_nama || 'Warga RT',
      l.warga_hp || '-',
      l.tanggal_pinjam || '-',
      l.tanggal_kembali || 'Masih Dipinjam',
      `${l.jumlah_pinjam || 1} Unit`,
      l.keperluan || l.catatan || '-',
      l.status === 'Kembali' ? 'Selesai / Kembali' : 'Dipinjam'
    ]);

    autoTable(doc, {
      startY: 46,
      head: headers,
      body: body,
      theme: 'grid',
      headStyles: {
        fillColor: [15, 23, 42],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 8.5,
        halign: 'center',
      },
      bodyStyles: {
        fontSize: 8,
        textColor: [30, 41, 59],
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },
      columnStyles: {
        0: { cellWidth: 10, halign: 'center' },
        1: { cellWidth: 40, fontStyle: 'bold' },
        2: { cellWidth: 38 },
        3: { cellWidth: 28 },
        4: { cellWidth: 24, halign: 'center' },
        5: { cellWidth: 26, halign: 'center' },
        6: { cellWidth: 20, halign: 'center', fontStyle: 'bold' },
        7: { cellWidth: 55 },
        8: { cellWidth: 28, halign: 'center', fontStyle: 'bold' },
      },
      margin: { left: 14, right: 14 },
    });
  } else {
    // DAFTAR INVENTARIS & ASET
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(12);
    doc.text(`LAPORAN DAFTAR INVENTARIS & ASET RT.${rtStr} RW.${rwStr}`, 14, 37);

    doc.setFontSize(8.5);
    doc.setFont('Helvetica', 'normal');
    
    const totalUnit = assets.reduce((sum, a) => sum + (Number(a.jumlah_total) || 0), 0);
    const totalBaik = assets.reduce((sum, a) => sum + (Number(a.jumlah_baik) || 0), 0);
    const totalRusak = assets.reduce((sum, a) => sum + (Number(a.jumlah_rusak) || 0), 0);

    doc.text(
      `Cakupan: ${filterLabel} | Total: ${assets.length} Jenis Barang (${totalUnit} Unit: ${totalBaik} Siap Digunakan, ${totalRusak} Rusak) | Tanggal Cetak: ${tglCetak}`,
      14,
      42
    );

    const headers = [
      ['NO', 'NAMA BARANG / PERALATAN', 'KONDISI', 'TOTAL UNIT', 'TERSEDIA (BAIK)', 'RUSAK', 'LOKASI PENYIMPANAN', 'KETERANGAN / SPESIFIKASI']
    ];

    const body: any[] = assets.map((a, idx) => [
      idx + 1,
      a.nama_barang || '-',
      a.kondisi || 'Baik',
      `${a.jumlah_total || 0} Unit`,
      `${a.jumlah_baik || 0} Unit`,
      `${a.jumlah_rusak || 0} Unit`,
      a.lokasi_penyimpanan || 'Gudang RT',
      a.catatan || '-'
    ]);

    // Baris total rekap di baris terakhir tabel
    body.push([
      '',
      'TOTAL REKAPITULASI INVENTARIS',
      `${assets.length} Jenis`,
      `${totalUnit} Unit`,
      `${totalBaik} Unit`,
      `${totalRusak} Unit`,
      '-',
      'Dokumen Resmi Aset RT'
    ]);

    autoTable(doc, {
      startY: 46,
      head: headers,
      body: body,
      theme: 'grid',
      headStyles: {
        fillColor: [15, 23, 42],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 8.5,
        halign: 'center',
      },
      bodyStyles: {
        fontSize: 8,
        textColor: [30, 41, 59],
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },
      columnStyles: {
        0: { cellWidth: 10, halign: 'center' },
        1: { cellWidth: 50, fontStyle: 'bold' },
        2: { cellWidth: 26, halign: 'center' },
        3: { cellWidth: 24, halign: 'center', fontStyle: 'bold' },
        4: { cellWidth: 28, halign: 'center', fontStyle: 'bold', textColor: [5, 150, 105] },
        5: { cellWidth: 22, halign: 'center', fontStyle: 'bold', textColor: [225, 29, 72] },
        6: { cellWidth: 45 },
        7: { cellWidth: 64 },
      },
      didParseCell: function(data) {
        if (data.row.index === body.length - 1) {
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [241, 245, 249];
          data.cell.styles.textColor = [15, 23, 42];
        }
      },
      margin: { left: 14, right: 14 },
    });
  }

  // Tanda Tangan Resmi
  const finalY = (doc as any).lastAutoTable?.finalY || 150;
  const signY = finalY + 8 > 165 ? 165 : finalY + 8;
  const locationName = options.sekretariat?.kelurahan || options.sekretariat?.kota_kabupaten || 'Pondok Rajeg';

  if (signY < 185) {
    doc.setFontSize(8.5);
    doc.setFont('Helvetica', 'normal');
    doc.setTextColor(30, 41, 59);

    // Kiri: Petugas / Seksi Sarana & Prasarana
    doc.text(`${locationName}, ${tglCetak}`, 30, signY);
    doc.text(`Pengelola Aset / Seksi Sarana,`, 30, signY + 5);
    doc.setFont('Helvetica', 'bold');
    doc.text(`${saranaNama}`, 30, signY + 20);
    doc.setDrawColor(30, 41, 59);
    doc.setLineWidth(0.4);
    doc.line(30, signY + 23, 85, signY + 23);
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`Seksi Sarana & Prasarana RT.${rtStr} RW.${rwStr}`, 30, signY + 28);

    // Kanan: Mengetahui Ketua RT
    doc.setFontSize(8.5);
    doc.text(`Mengetahui,`, 220, signY + 5);
    doc.setFont('Helvetica', 'bold');
    doc.text(`${ketuaNama}`, 220, signY + 20);
    doc.setDrawColor(30, 41, 59);
    doc.setLineWidth(0.4);
    doc.line(220, signY + 23, 275, signY + 23);
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`${ketuaJabatan}`, 220, signY + 28);
  }

  // Footer Nomor Halaman
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setFont('Helvetica', 'italic');
    doc.setTextColor(100, 116, 139);
    doc.text(
      `Halaman ${i} dari ${pageCount} — Dokumen Resmi Inventaris & Aset RT.${rtStr} RW.${rwStr}`,
      14,
      202
    );
  }

  const defaultFilename = isLoanTab 
    ? `Laporan_Peminjaman_Aset_RT${rtStr}_RW${rwStr}_${new Date().toISOString().split('T')[0]}.pdf`
    : `Laporan_Inventaris_Aset_RT${rtStr}_RW${rwStr}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(options.filename || defaultFilename);
}

/**
 * Ekspor data susunan pengurus & akun pengguna RT ke format PDF Laporan Resmi
 */
export async function exportDataPengurusPDF(
  pengurusList: SupabasePengurusRow[],
  options: {
    sekretariat?: {
      rt?: string;
      rw?: string;
      kelurahan?: string;
      kecamatan?: string;
      alamat?: string;
      kota_kabupaten?: string;
      provinsi?: string;
      nama_ketua_rt?: string;
    };
    filterLabel?: string;
    filename?: string;
  } = {}
): Promise<void> {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  const rtStr = options.sekretariat?.rt || '002';
  const rwStr = options.sekretariat?.rw || '09';
  const kelStr = (options.sekretariat?.kelurahan || 'Pondok Rajeg').toUpperCase();
  const kecStr = (options.sekretariat?.kecamatan || 'Cibinong').toUpperCase();
  const alamatStr = options.sekretariat?.alamat || `RT.${rtStr} RW.${rwStr}, Kel. ${options.sekretariat?.kelurahan || 'Pondok Rajeg'}`;

  // 1. Saring hanya pengurus (Keluarkan yang berstatus/jabatan Warga)
  // 2. Urutkan sesuai hierarki jabatan RT: Ketua, Wakil Ketua, Sekretaris, Bendahara, Seksi-Seksi, dst.
  const validPengurus = (pengurusList || [])
    .filter((p) => !isWargaJabatan(p.jabatan))
    .slice()
    .sort(sortPengurusByJabatan);

  // Cari Ketua RT untuk tanda tangan
  const ketuaUser = validPengurus.find((p) => 
    p.jabatan && p.jabatan.toLowerCase().includes('ketua') && !p.jabatan.toLowerCase().includes('wakil')
  ) || validPengurus.find((p) => p.level_akses === 'Admin') || validPengurus[0];

  const ketuaNama = ketuaUser?.nama || options.sekretariat?.nama_ketua_rt || 'Bpk. Ketua RT';
  const ketuaJabatan = ketuaUser?.jabatan || `Ketua RT.${rtStr} RW.${rwStr}`;

  // 4. Sertakan Logo RT di kiri atas beserta identitas RT/RW di bawah logo
  let logoDataUrl: string | null = null;
  try {
    logoDataUrl = await getRtLogoBase64();
  } catch (e) {
    console.warn('[PDF Export] Logo load error', e);
  }

  if (logoDataUrl) {
    // Logo diletakkan di kiri atas mulai x = 5.5mm, y = 4.5mm, ukuran 13.5x13.5 mm
    doc.addImage(logoDataUrl, 'PNG', 5.5, 4.5, 13.5, 13.5);
  }

  // Teks RT & RW di bawah Logo RT
  const cleanRt = String(rtStr).replace(/^RT\.?\s*/i, '');
  const cleanRw = String(rwStr).replace(/^RW\.?\s*/i, '');
  const rtRwSubText = `RT. ${cleanRt}, RW. ${cleanRw}`;

  doc.setFontSize(6.5);
  doc.setFont('Helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text(rtRwSubText, 12.25, 19.7, { align: 'center' });

  // Header Kop Surat (Center pada x = 105mm)
  doc.setFontSize(13);
  doc.setFont('Helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(`RUKUN TETANGGA ${rtStr} / RUKUN WARGA ${rwStr}`, 105, 10, { align: 'center' });

  doc.setFontSize(9.5);
  doc.text(`KELURAHAN ${kelStr} - KECAMATAN ${kecStr}`, 105, 15, { align: 'center' });

  doc.setFontSize(8);
  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text(alamatStr, 105, 19.5, { align: 'center' });

  // Garis Pembatas Kop Surat (Margin Left: 4mm, Right: 4mm -> lebar x: 4 sampai 206)
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.8);
  doc.line(4, 22.5, 206, 22.5);
  doc.setLineWidth(0.2);
  doc.line(4, 23.5, 206, 23.5);

  // Judul Dokumen (digeser ke bawah agar memiliki ruang lega dari kop surat)
  doc.setFontSize(11);
  doc.setFont('Helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('STRUKTUR ORGANISASI & SUSUNAN PENGURUS RT', 105, 33, { align: 'center' });

  doc.setFontSize(8);
  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  const now = new Date();
  const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  const tglCetak = `${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
  doc.text(`Periode Aktif • Dicetak pada: ${tglCetak}${options.filterLabel ? ` • Filter: ${options.filterLabel}` : ''}`, 105, 37.5, { align: 'center' });

  // 1. Siapkan Data Tabel (Kolom Kategori dan Kolom Hak Akses Dihapus, Teks 'Terkait Warga' setelah Alamat Dihapus)
  const tableRows = validPengurus.map((p, idx) => {
    const rawAlamat = p.alamat_domisili || '-';
    const cleanAlamat = rawAlamat.replace(/\s*\(?Terkait Warga\)?/gi, '').trim() || '-';

    return [
      String(idx + 1),
      p.nama || '-',
      p.jabatan || '-',
      p.email || '-',
      p.no_hp || '-',
      cleanAlamat
    ];
  });

  // 1. Kolom Kategori dan Hak Akses telah dihapus (tersisa 6 kolom)
  // 2. Lebar kolom Nama Lengkap & Email Akun dikurangi, lebar kolom Alamat Domisili ditambah proporsional
  // 3. Margin Left & Right = 4 mm, Top & Bottom = 6 mm (Total lebar kerja 202 mm)
  // 4. Baris dirapatkan (cellPadding: 1.2 mm) agar rapi & proporsional
  autoTable(doc, {
    startY: 41,
    head: [['No', 'Nama Lengkap', 'Jabatan / Posisi', 'Email Akun', 'No. HP', 'Alamat Domisili']],
    body: tableRows,
    theme: 'grid',
    styles: {
      fontSize: 8,
      cellPadding: 1.2,
      font: 'Helvetica',
      textColor: [30, 41, 59],
      lineColor: [226, 232, 240],
      lineWidth: 0.1,
      valign: 'middle',
    },
    headStyles: {
      fillColor: [15, 23, 42],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      cellPadding: 1.8,
      halign: 'center', // Judul kolom di posisi tengah
      valign: 'middle',
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 36, fontStyle: 'bold' }, // Nama Lengkap dikurangi dari 46 ke 36 mm
      2: { cellWidth: 40 },
      3: { cellWidth: 30 }, // Email Akun dikurangi dari 42 ke 30 mm
      4: { cellWidth: 26, halign: 'center' },
      5: { cellWidth: 60 }, // Alamat Domisili ditambah proporsional dari 38 ke 60 mm
    },
    margin: { top: 6, bottom: 6, left: 4, right: 4 },
  });

  // Tanda Tangan Ketua RT
  const finalY = (doc as any).lastAutoTable ? (doc as any).lastAutoTable.finalY + 8 : 120;
  let signY = finalY;
  if (signY > 262) {
    doc.addPage();
    signY = 14;
  }

  const locationName = options.sekretariat?.kelurahan || 'Pondok Rajeg';
  doc.setFontSize(8.5);
  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(30, 41, 59);

  doc.text(`${locationName}, ${tglCetak}`, 142, signY);
  doc.text(`Ketua RT.${rtStr} RW.${rwStr},`, 142, signY + 4.5);

  doc.setFont('Helvetica', 'bold');
  doc.text(`${ketuaNama}`, 142, signY + 19);

  doc.setDrawColor(30, 41, 59);
  doc.setLineWidth(0.4);
  doc.line(142, signY + 21.5, 203, signY + 21.5);

  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(`${ketuaJabatan}`, 142, signY + 26);

  // Footer Nomor Halaman (Margin Left: 4mm, Bottom: 6mm)
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setFont('Helvetica', 'italic');
    doc.setTextColor(100, 116, 139);
    doc.text(
      `Halaman ${i} dari ${pageCount} — Dokumen Susunan Pengurus RT.${rtStr} RW.${rwStr}`,
      4,
      292
    );
  }

  const defaultFilename = `Susunan_Pengurus_RT${rtStr}_RW${rwStr}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(options.filename || defaultFilename);
}



